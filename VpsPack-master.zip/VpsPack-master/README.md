# VpsPack

# Install

wget https://raw.githubusercontent.com/RicKbrL/VpsPack/master/install && bash install
